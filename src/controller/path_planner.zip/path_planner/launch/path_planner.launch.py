#!/usr/bin/env python3

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # Get the package directory
    package_dir = get_package_share_directory('path_planner')

    # Declare launch arguments
    csv_file_path_arg = DeclareLaunchArgument(
        'csv_file_path',
        default_value='/home/dawgs_nx/f1tenth_dawgs/src/peripheral/racetracks/levine/levine_blacked_lippboyd_speedopted_V2.csv',
        description='Path to the CSV file containing waypoints (x,y,v,kappa format)'
    )

    global_path_topic_arg = DeclareLaunchArgument(
        'global_path_topic',
        default_value='/global_centerline',
        description='Topic name for publishing the global path'
    )

    planned_path_topic_arg = DeclareLaunchArgument(
        'planned_path_topic',
        default_value='/planned_path',
        description='Topic name for publishing the local path'
    )

    frame_id_arg = DeclareLaunchArgument(
        'frame_id',
        default_value='map',
        description='Frame ID for the published path'
    )

    planner_horizon_arg = DeclareLaunchArgument(
        'planner_horizon',
        default_value='3.0',
        description='Planning horizon distance in meters'
    )

    frenet_path_topic_arg = DeclareLaunchArgument(
        'frenet_path_topic',
        default_value='/frenet_path',
        description='Topic name for Frenet path visualization'
    )

    lut_path_topic_arg = DeclareLaunchArgument(
        'lut_path_topic',
        default_value='/lut_path',
        description='Topic name for LUT path visualization'
    )

    visualize_paths_arg = DeclareLaunchArgument(
        'visualize_paths',
        default_value='true',
        description='Enable visualization of Frenet and LUT paths'
    )

    use_lattice_arg = DeclareLaunchArgument(
        'use_lattice',
        default_value='true',
        description='Use lattice planner'
    )

    use_frenet_arg = DeclareLaunchArgument(
        'use_frenet',
        default_value='true',
        description='Use Frenet planner'
    )

    # Path Planner Node with integrated CSV reading
    path_planner_node = Node(
        package='path_planner',
        executable='path_planner_node',
        name='path_planner_node',
        output='screen',
        parameters=[{
            'csv_file_path': LaunchConfiguration('csv_file_path'),
            'global_path_topic': LaunchConfiguration('global_path_topic'),
            'planned_path_topic': LaunchConfiguration('planned_path_topic'),
            'frenet_path_topic': LaunchConfiguration('frenet_path_topic'),
            'lut_path_topic': LaunchConfiguration('lut_path_topic'),
            'frame_id': LaunchConfiguration('frame_id'),
            'planner_horizon': LaunchConfiguration('planner_horizon'),
            'visualize_paths': LaunchConfiguration('visualize_paths'),
            'use_lattice': LaunchConfiguration('use_lattice'),
            'use_frenet': LaunchConfiguration('use_frenet'),
            'publish_rate': 1.0
        }],
        remappings=[
            ('/odom', '/ego_racecar/odom'),
        ]
    )

    return LaunchDescription([
        csv_file_path_arg,
        global_path_topic_arg,
        planned_path_topic_arg,
        frenet_path_topic_arg,
        lut_path_topic_arg,
        frame_id_arg,
        planner_horizon_arg,
        visualize_paths_arg,
        use_lattice_arg,
        use_frenet_arg,
        path_planner_node
    ])